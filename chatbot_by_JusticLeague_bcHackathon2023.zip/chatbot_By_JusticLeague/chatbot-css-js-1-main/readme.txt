This application is developed for the college Hackathon project and belong to Ayub, Justin, Edna and Winnie.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

User Manual 
..............

The index file contains breif explanation of the Bellevue College and an AI chatBot.
All of the links are alive and directed to the specific directories of the actual Bellevue College website and the googleMap.

The AI may ask for the permission to use Microphone and additionally make sure the browser is allowed any app for window pop up.

In chrome, change your default pop-ups & redirects settings

On your computer, open Chrome.
At the top right, click More and/or then Settings.
Click Privacy and security and then Site Settings and then Pop-ups and redirects.
Choose the option that you want as your default setting.

AI only works with Specified keywords

the keywords are listed in a specific Object of the response.js file and open with an editor, the left side of the equation is keywords and the right side is response.

ENJOY ! THANKS FOR YOUR TIME

