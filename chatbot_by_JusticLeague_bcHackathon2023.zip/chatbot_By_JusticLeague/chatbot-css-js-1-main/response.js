const responseObj = {
  "hello": "Hey! How are you doing?",
  "hey": "Hey! What's up?",
  "Hey.":"Hey ! What's up?",
  "hi": "Hi!",
  "Hi.": "Hi.",
  "who are you": "I am BC Bulldog, your friendly fellow. How can I help you ?",
  "open youtube": "https://www.youtube.com/@BellevueCollege",
  "open degree" : "https://www.bellevuecollege.edu/programs/",
  "open services": "https://www.bellevuecollege.edu/resources/",
};


